-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 23, 2024 at 03:28 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `systmanagedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int NOT NULL,
  `projectName` varchar(255) NOT NULL,
  `projectDescription` text NOT NULL,
  `status` varchar(255) NOT NULL,
  `priority` varchar(255) NOT NULL,
  `budget` float DEFAULT NULL,
  `startAt` datetime NOT NULL,
  `endAt` datetime NOT NULL,
  `note` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `projectName`, `projectDescription`, `status`, `priority`, `budget`, `startAt`, `endAt`, `note`, `createdAt`, `updatedAt`) VALUES
(1, 'Gmg solution', '<p><strong>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, itaque nam facilis aliquid expedita hic deleniti adipisci, necessitatibus modi aut tempora? Quaerat odio minus accusantium quas officia tempore .</strong></p><p><strong>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, itaque nam facilis aliquid expedita hic deleniti adipisci, necessitatibus modi aut tempora? Quaerat odio minus </strong><i><strong>accusantium quas officia tempore quo natus earum aperiam veritatis incidunt eligendi, perspiciatis officiis nulla doloremque voluptate voluptatibus fuga suscipit nihil sint! Maxime repudiandae praesentium aperiam, nisi fugit dolores vero libero omnis odit corrupti similique, consequatur arum. Reprehenderit pariatur, quod veniam .</strong></i></p>', '4', 'high', 1222, '2024-07-18 00:00:00', '2024-07-18 00:00:00', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, itaque nam facilis aliquid expedita hic deleniti adipisci, necessitatibus modi aut tempora? Quaerat odio minus accusantium quas officia tempore quo natus earum aperiam veritatis incidunt eligendi, perspiciatis officiis nulla doloremque voluptate voluptatibus fuga suscipit nihil sint! Maxime repudiandae praesentium aperiam, nisi fugit dolores vero libero omnis odit corrupti similique, consequatur accusantium eos dignissimos delectus, in quod minus non quasi ad. Quod, assumenda corporis, quas aperiam temporibus excepturi recusandae reprehenderit impedit deserunt distinctio animi magnam earum. Reprehenderit pariatur, quod veniam commodi minima natus temporibus animi, voluptatem officia necessitatibus nesciunt in quo impedit.\n', '2024-07-18 14:38:31', '2024-07-22 11:48:27'),
(2, 'Team', '<p><strong>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, itaque nam facilis aliquid expedita hic deleniti adipisci, necessitatibus modi aut tempora? Quaerat odio minus accusantium quas officia tempore quo natus earum aperiam veritatis incidunt eligendi, perspiciatis officiis nulla doloremque voluptate voluptatibus fuga suscipit nihil sint! Maxime repudiandae praesentium aperiam, nisi fugit dolores vero libero omnis odit corrupti similique, consequatur accusantium eos dignissimos delectus, in quod minus non quasi ad. Quod, assumenda corporis, quas aperiam temporibus excepturi recusandae reprehenderit impedit deserunt distinctio animi magnam earum. Reprehenderit pariatur, quod veniam commodi minima natus temporibus animi, voluptatem officia necessitatibus nesciunt in quo impedit.</strong></p>', '4', 'high', 2000, '2024-07-18 00:00:00', '2024-07-27 00:00:00', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, itaque nam facilis aliquid expedita hic deleniti adipisci, necessitatibus modi aut tempora? Quaerat odio minus accusantium quas officia tempore quo natus earum aperiam veritatis incidunt eligendi, perspiciatis officiis nulla doloremque voluptate voluptatibus fuga suscipit nihil sint! Maxime repudiandae praesentium aperiam, nisi fugit dolores vero libero omnis odit corrupti similique, consequatur accusantium eos dignissimos delectus, in quod minus non quasi ad. Quod, assumenda corporis, quas aperiam temporibus excepturi recusandae reprehenderit impedit deserunt distinctio animi magnam earum. Reprehenderit pariatur, quod veniam commodi minima natus temporibus animi, voluptatem officia necessitatibus nesciunt in quo impedit.\n', '2024-07-18 14:39:12', '2024-07-19 09:34:22'),
(3, 'Education', '<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cupiditate earum ea dolore fugit. Dignissimos eius quo quam esse sapiente ullam architecto aliquid quasi doloremque, voluptas laborum sit at velit est a cupiditate nam nesciunt autem laboriosam atque soluta inventore suscipit facere iusto. Enim natus dolore distinctio est debitis ipsam fugit saepe in culpa commodi corporis odio maiores, quaerat recusandae voluptatum veniam totam, consectetur a aspernatur blanditiis error mollitia temporibus voluptatem. Earum exercitationem natus sint animi, iure illo, autem necessitatibus fuga delectus maxime officiis ex ipsam, vel laborum nemo nostrum nesciunt tempora illum numquam officia veniam! Impedit mollitia aliquid ea sed.</p>', '4', '13', 2000, '2024-07-23 00:00:00', '2024-07-26 00:00:00', '              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cupiditate earum ea dolore fugit. Dignissimos eius quo quam esse sapiente ullam architecto aliquid quasi doloremque, voluptas laborum sit at velit est a cupiditate nam nesciunt autem laboriosam atque soluta inventore suscipit facere iusto. Enim natus dolore distinctio est debitis ipsam fugit saepe in culpa commodi corporis odio maiores, quaerat recusandae voluptatum veniam totam, consectetur a aspernatur blanditiis error mollitia temporibus voluptatem. Earum exercitationem natus sint animi, iure illo, autem necessitatibus fuga delectus maxime officiis ex ipsam, vel laborum nemo nostrum nesciunt tempora illum numquam officia veniam! Impedit mollitia aliquid ea sed.\n', '2024-07-23 14:57:11', '2024-07-23 14:57:11'),
(4, 'School', '<p>Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management v</p>', '4', '2', 10000, '2024-07-23 00:00:00', '2024-07-27 00:00:00', 'Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management Project Management v', '2024-07-23 15:06:13', '2024-07-23 15:06:13'),
(5, 'Bottle', '<p>I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status.&nbsp;</p>', '8', '2', 2000, '2024-07-23 00:00:00', '2024-07-26 00:00:00', 'I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. I am status. ', '2024-07-23 15:10:19', '2024-07-23 15:10:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
